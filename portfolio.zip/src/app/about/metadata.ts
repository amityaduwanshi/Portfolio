export const metadata = {
  title: 'About Me | Amit Yaduwanshi',
  description: 'Learn more about Amit Yaduwanshi, Senior Software Architect, consultant, and mentor.',
}; 